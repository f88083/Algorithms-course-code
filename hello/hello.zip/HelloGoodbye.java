/* *****************************************************************************
 *  Name:              Shih-Che, Lai
 *  Coursera User ID:  123456
 *  Last modified:     2023/9/28
 **************************************************************************** */

public class HelloGoodbye {
    public static void main(String[] args) {
        String first = args[0];
        String second = args[1];

        System.out.println("Hello " + first + " and " + second + ".");

        System.out.println("Goodbye " + second + " and " + first + ".");
    }
}
